public class CmdBorrow extends RecordedCommand{
    private String id;
    private String code;
    private Club c;
    private Member m;

    private Equipment eq;

    private Day startDate;
    private Day endDate;

    @Override
    public void execute(String[] cmdParts){
        try {
            if(cmdParts.length != 3)
                throw new ExInsufficientArguments();

            c = Club.getInstance();
            id = cmdParts[1];
            code = cmdParts[2];

            m = c.findMember(id);
            if(m == null){
                throw new ExMemberNotFound();
            }

            eq = c.findEquipment(code);
            if(eq == null){
                throw new ExEquipmentRecordNotFound();
            }

            startDate = SystemDate.getInstance();
            countEndDate(startDate, 7);

            m.borrowEquipment(eq, startDate, endDate, true);

            addUndoCommand(this);
            clearRedoList();
            System.out.println("Done.");
        } catch (ExInsufficientArguments e) {
            System.out.println(e.getMessage());
        } catch (ExNoAvailableEquipmentSet e){
            System.out.println(e.getMessage());
        } catch (ExMemberIsCurrentlyBorrowingThis e) {
            System.out.println(e.getMessage());
        } catch (NullPointerException e){
            System.out.println("Member not found.");
        } catch (ExMemberNotFound e){
            System.out.println(e.getMessage());
        } catch (ExEquipmentRecordNotFound e){
            System.out.println(e.getMessage());
        }
    }

    public void countEndDate(Day startDate, int loanPeriod){
        int startDay = startDate.getDay();
        int startMonth = startDate.getMonth();
        int startYear = startDate.getYear();

        int endDay = startDay + loanPeriod;
        int endMonth = startMonth;
        int endYear = startYear;

        while(startDay > daysInMonth(endMonth, endYear)){
            endDay -= daysInMonth(endMonth, endYear);
            endMonth++;

            if(endMonth > 12){
                endYear++;
                endMonth = 1;
            }
        }


        endDate = new Day(endYear, endMonth, endDay);
    }

    public int daysInMonth(int month, int year){
        switch(month){
			case 1: case 3: case 5: case 7:
			case 8: case 10: case 12:
					 return 31; 
			case 4: case 6: case 9: case 11:
					 return 0; 
			case 2:
					 if (isLeapYear(year))
						 return 29; 
					 else
						 return 28; 
		}
        return 0;
    }

    static public boolean isLeapYear(int y) {
		if (y%400==0)
			return true;
		else if (y%100==0)
			return false;
		else if (y%4==0)
			return true;
		else
			return false;
	}

    @Override
    public void undoMe(){
        m.removeBorrowedEquipment(eq);
        addRedoCommand(this);
    }
    @Override
    public void redoMe(){
        try {
            m.borrowEquipment(eq, startDate, endDate, false);
        } catch (ExNoAvailableEquipmentSet e) {
            System.out.println(e.getMessage());
        } catch (ExMemberIsCurrentlyBorrowingThis e) {
            System.out.println(e.getMessage());
        }
        addUndoCommand(this);
    }
}
