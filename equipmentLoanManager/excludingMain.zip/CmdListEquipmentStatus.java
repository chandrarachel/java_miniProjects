public class CmdListEquipmentStatus extends RecordedCommand{
    private Club c;

    @Override
    public void execute(String[] cmdParts){
        c = Club.getInstance();
        c.listEquipmentStatus();
    }

    @Override
    public void undoMe(){}
    @Override
    public void redoMe(){}
}
