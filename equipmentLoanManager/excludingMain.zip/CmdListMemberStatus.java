public class CmdListMemberStatus extends RecordedCommand{
    private Club c;
    
    @Override
    public void execute(String[] cmdParts){
        c = Club.getInstance();
        c.listMemberStatus();
    }

    @Override
    public void undoMe(){}

    @Override
    public void redoMe(){}
}
