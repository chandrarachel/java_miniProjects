public class CmdListEquipment implements Command {
    private Club c;
    
    @Override
    public void execute(String[] cmdParts) {
        // Equipment eq = Equipment.getInstance();
        // eq.listEquipmentSets();
        c = Club.getInstance();
        c.listEquipments();
    }
}
